package testCases;

import org.testng.annotations.Test;

public class MiscTesting {
  @Test
  public void test() {
	  System.out.println(System.getProperty("user.dir"));
  }
}
